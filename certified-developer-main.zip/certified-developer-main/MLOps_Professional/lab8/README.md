# Lab 8

Please follow instructions provided through the MLOps Professional Course content. 
