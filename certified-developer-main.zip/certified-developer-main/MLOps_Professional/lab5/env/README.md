# Lab 5

Lab 5 instructions have been updated on the course website. You will no longer use the VMs for this particular lab. Instead you will use the Jupyter Lab functionality under the "Learning" section of the Intel® Tiber™ AI Cloud. Please select the "PyTorch" kernel for a preconfigured environment for this lab. 
