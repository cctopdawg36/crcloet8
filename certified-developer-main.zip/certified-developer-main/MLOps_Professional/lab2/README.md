# Lab 2: Creating Architecture Diagrams from Application Specs
Please reference lab instructions in the learning management system to complete this lab. 