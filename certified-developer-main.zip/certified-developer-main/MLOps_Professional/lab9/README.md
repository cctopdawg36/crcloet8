# Lab 9

Please follow instructions provided through the MLOps Professional Course content. 
